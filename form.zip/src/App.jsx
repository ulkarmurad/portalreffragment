import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Navbar from './components/Navbar/Navbar'
import User from './components/Card/User'
import List from './components/List/List'
import Terminal from './components/StateFull/Terminal'
import Nav from './components/Nav/NAv'
import { useFriendStatus } from './customhook'
import ChatPage from './components/Event'
import Dropdown from './components/Dropdown/Dropdown'
import Loading from './components/Loading/LoadingBar'
import { Button, TomatoButton } from './atoms/Button'
import Form from './components/Form/FOrm'

function App() {
 const {status, miniEvent} = useFriendStatus()

  return (
    <>
    <Form/>
    {/* <Loading width='40px' height='40px'/>
    <Loading width='50px' height='50px'/>
    <Loading width='60px' height='60px'/>
    <Loading width='70px' height='70px'/>
    <Button>Click</Button>
    <br/>
    <br/>
    <Button $borderColor={"white"} $background={"lightblue"}>Signup</Button>
    <TomatoButton onClick={() => alert("clicked")} $borderColor={"white"} $background={"purple"}>Login</TomatoButton> */}
    </>
  )
}

export default App
